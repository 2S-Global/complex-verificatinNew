import Layout from "../components/Layout";
import DynamicForm from "../components/DynamicForm";

export default function newForm() {
  const fields = [
    { name: 'firstName', label: 'First Name', required: true, type: 'text' },
    { name: 'lastName', label: 'Last Name', required: true, type: 'text' },
    { name: 'email', label: 'Email', required: true, type: 'email' },

    {
      name: 'country',
      label: 'Country',
      type: 'select',
      options: [
        { value: 'usa', label: 'USA' },
        { value: 'canada', label: 'Canada' },
        { value: 'india', label: 'India' },
      ],
    },
    
    {
      name: 'gender',
      label: 'Gender',
      type: 'radio',
      options: [
        { value: 'male', label: 'Male' },
        { value: 'female', label: 'Female' },
        { value: 'other', label: 'Other' },
      ],
    },

    {
      name: 'subscribe',
      label: 'Subscribe to Newsletters',
      type: 'checkbox',
      options: [
        { value: 'news', label: 'News' },
        { value: 'offers', label: 'Special Offers' },
        { value: 'events', label: 'Events' },
      ],
      required: false,
    },

  
    { name: 'description', label: 'Description', required: true, type: 'textarea' },
    {
      name: 'resume',
      label: 'Upload Resume',
      type: 'file',
      required: true,
    },
  ];

  return (
    <Layout>
      <main id="main" className="main">
        <DynamicForm fields={fields} />
      </main>
    </Layout>
  );
}
