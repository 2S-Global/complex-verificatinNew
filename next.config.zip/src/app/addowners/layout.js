export const metadata = {
    title: "Add Owners",
    description: "Add a new Owner",
  };
  
  export default function AddDomesticUserLayout({ children }) {
    return <>{children}</>;
  }
  