export const metadata = {
    title: "Change Password",
    description: "Change Password",
  };
  
  export default function AddDomesticUserLayout({ children }) {
    return <>{children}</>;
  }
  