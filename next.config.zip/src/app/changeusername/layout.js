export const metadata = {
    title: "Change Username",
    description: "Change Username",
  };
  
  export default function AddDomesticUserLayout({ children }) {
    return <>{children}</>;
  }
  