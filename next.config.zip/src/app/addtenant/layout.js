export const metadata = {
    title: "Add Tenant",
    description: "Add Tenant",
  };
  
  export default function AddDomesticUserLayout({ children }) {
    return <>{children}</>;
  }
  