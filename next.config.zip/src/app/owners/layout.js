export const metadata = {
    title: "List Owners",
    description: "List Owners",
  };
  
  export default function AddDomesticUserLayout({ children }) {
    return <>{children}</>;
  }
  