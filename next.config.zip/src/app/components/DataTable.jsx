"use client";

import { useState, useMemo } from "react";
import { DataGrid } from "@mui/x-data-grid";
import { Box, TextField } from "@mui/material";

// ✅ Function to check if a value is an image URL
const isImageURL = (value) => {
  return (
    typeof value === "string" &&
    (value.startsWith("http://") || value.startsWith("https://"))
  );
};

const DataTable = ({ fields, data }) => {
  const [searchText, setSearchText] = useState("");
  const [paginationModel, setPaginationModel] = useState({
    pageSize: 10,
    page: 0,
  });

  // ✅ Generate columns dynamically with renderCell logic
  const columns = useMemo(() => {
    return fields.map((field) => ({
      field: field.name,
      headerName: field.label,
      flex: 1,
      minWidth: 150,
      renderCell: (params) =>
        isImageURL(params.value) ? (
          <img
            src={params.value}
            alt="Image"
            style={{ width: 50, height: 50, borderRadius: "50%" }} // Fixed size
          />
        ) : (
          params.value || "-" // Show normal text for non-image fields, default to "-"
        ),
    }));
  }, [fields]);

  // ✅ Adjust row height dynamically
  const getRowHeight = (params) => {
    if (!params?.row) return 50; // Default height in case of missing data
    return Object.values(params.row).some((value) => isImageURL(value)) ? 100 : 50;
  };

  // ✅ Filter rows based on search input
  const filteredRows = useMemo(
    () =>
      data.filter((row) =>
        Object.values(row)
          .join(" ")
          .toLowerCase()
          .includes(searchText.toLowerCase())
      ),
    [data, searchText]
  );

  return (
    <Box sx={{ width: "100%", p: 2, display: "flex", flexDirection: "column", height: "100%" }}>
      {/* ✅ Right-aligned Search Bar */}
      <Box sx={{ display: "flex", justifyContent: "flex-end", mb: 2 }}>
        <TextField
          label="Search"
          variant="outlined"
          size="small"
          sx={{ width: "200px" }}
          onChange={(e) => setSearchText(e.target.value)}
        />
      </Box>

      {/* ✅ Paginated Table */}
      <Box sx={{ flexGrow: 1, height: "auto", width: "100%" }}>
        <DataGrid
          rows={filteredRows}
          columns={columns}
          pageSizeOptions={[10]} // ✅ Limit Rows Per Page
          paginationModel={paginationModel}
          onPaginationModelChange={setPaginationModel}
          pagination
          disableSelectionOnClick
          getRowHeight={getRowHeight} // ✅ Dynamic row height for images
          sx={{
            "& .MuiDataGrid-row": {
              maxHeight: "none !important", // Force override MUI row height limits
              minHeight: "auto !important",
            },
          }}
        />
      </Box>
    </Box>
  );
};

export default DataTable;
