"use client"; // ✅ Ensure it's a Client Component

import { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import { CircularProgress } from "@mui/material";
import Layout from "../components/Layout";

// ✅ Dynamically Import DataTable (Client-Side Only)
const DataTable = dynamic(() => import("../components/DataTable"), {
  ssr: false, // ✅ Prevents SSR, avoiding hydration mismatch
});

const fields = [
  { name: "id", label: "ID" },
  { name: "name", label: "Name" },
  { name: "email", label: "Email" },
];

const data = [
  { id: 1, name: "John Doe", email: "john@example.com" },
  { id: 2, name: "Jane Doe", email: "jane@example.com" },
  ...Array.from({ length: 100 }, (_, i) => ({
    id: i + 3,
    name: `User ${i + 3}`,
    email: `user${i + 3}@example.com`,
  })),
];


export default function Page() {
  const [isMounted, setIsMounted] = useState(false);

  // ✅ Wait until mounted to prevent SSR mismatch
  useEffect(() => {
    setIsMounted(true);
  }, []);

  return (
    <Layout>
      <main id="main" className="main">
        <section className="section">
          <div className="row">
            <div className="col-lg-12">
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">List Domestic User</h5>

                  {/* ✅ Show loader until mounted to prevent mismatch */}
                  {!isMounted ? (
                    <div
                      style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        height: "100px",
                      }}
                    >
                      <CircularProgress />
                    </div>
                  ) : (
                    <DataTable fields={fields} data={data} />
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </Layout>
  );
}
