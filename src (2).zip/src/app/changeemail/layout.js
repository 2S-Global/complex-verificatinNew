export const metadata = {
    title: "Change Email",
    description: "Change Email",
  };
  
  export default function AddDomesticUserLayout({ children }) {
    return <>{children}</>;
  }
  