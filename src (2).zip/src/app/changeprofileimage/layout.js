export const metadata = {
    title: "Change Profile Image",
    description: "Change Profile Image",
  };
  
  export default function AddDomesticUserLayout({ children }) {
    return <>{children}</>;
  }
  