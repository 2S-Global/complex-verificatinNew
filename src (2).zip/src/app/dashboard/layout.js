export const metadata = {
    title: "Dashboard",
    description: "Dashboard",
  };
  
  export default function AddDomesticUserLayout({ children }) {
    return <>{children}</>;
  }
  