export const metadata = {
    title: "List Domestic User",
    description: "List Domestic User",
  };
  
  export default function AddDomesticUserLayout({ children }) {
    return <>{children}</>;
  }
  