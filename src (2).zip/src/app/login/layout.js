export const metadata = {
    title: "Login",
    description: "Login",
  };
  
  export default function AddDomesticUserLayout({ children }) {
    return <>{children}</>;
  }
  