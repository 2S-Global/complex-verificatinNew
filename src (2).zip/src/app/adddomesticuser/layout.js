export const metadata = {
    title: "Add Domestic User",
    description: "Add a new domestic user",
  };
  
  export default function AddDomesticUserLayout({ children }) {
    return <>{children}</>;
  }
  